inside folder cryptopp:
  - libcryptopp.a

inside folder tcp:
  - libmytcp.a

inside folder ssl:
  - libmyssl.a
