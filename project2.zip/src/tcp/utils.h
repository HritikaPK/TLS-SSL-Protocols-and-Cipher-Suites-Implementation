#include <string>

int get_publichostname(std::string *hostname);

int get_datetime(std::string *datetime, const char* format);

